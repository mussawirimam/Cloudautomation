# print("Welcome to calculator!")

# print("Please enter your marks!")

# sub1 = int(input("Subject 1: "))
# sub2 = int(input("Subject 2: "))
# sub3 = int(input("Subject 3: "))
# sub4 = int(input("Subject 4: "))
# sub5 = int(input("Subject 5: "))

# print(type(sub1))

# total = sub1 + sub2 + sub3 + sub4 + sub5

# average = total / 5

# print(type(average))
# print(type(total))

# # average = earned_mark/total_marks*100

# if average >= 90:
#     if average >= 95:
#         print("You have scored top 5% students!")
#         if average >= 97:
#             print("You have scored top 1%!")
#             if average == 100:
#                 print("You are the achiever! You scored centum!")
#     print("You secured Distinction!")
#     print("You are one of the topper")
#     print("congratulations")
# elif average >= 80:
#     print("You secured first class!")
#     print("Congratulations!")
# elif average >= 70:
#     print("You secured second class!")
#     print("Congratulations!")
# else:
#     print("You have to score more to pass! Try Harder!")


# print("thank you!")

# get the user input a number - identify whether the number is positive or negative or zero

# Data type
# integer , float, complex, binary, oct, hexa - numeric datatype
# string
# list - holds a list of values
# tuple -
# set
# dict -

# a = 10
# b = 10.5
# c = 5+6j

# print(type(a))
# print(type(b))
# print(type(c))

# print(0b1010010101) # binary

# print(0o12321432412) #octal

# print(0x312B32) #hexa decimal

# # List

# a = [10,212,213,123,213,4,435,324,342,2343,23,423,423,423,42,34,234,234,23,423,42,34,234,23,423,4,234235,345,657]
# b = ["santhosh", "vinesh", "nanda", "ashif"]
# c = [10,213,34,"santhosh","vinesh"]

# # print(type(a))
# # print(type(b))
# # print(type(c))
# print(a)
# a.append(1000)

# z = a.copy()
# z.extend(b)

# print(a)
# print(z)

# a.insert(0,3897489372)
# print(a)
# a.remove(123)
# print(a)

# # a.clear()

# print(a.count(213))

# print(a.index(4))

# a.pop()
# print(a)


# print(a.pop())
# print(a)

# print(dir(a))

# a.reverse()

# print(a)

# a.sort()
# print(a)

# print(a[0])
# print(a[1])
# print(a[2])
# length = len(a)
# print(length)

# print(a[1:5])
# print(a)


# print(a[len(a):len(a)-6:-1])

# print(a)

# my_tuple = ("apple","orange","banana","litchi", "apple") #immutable

# print(type(my_tuple))
# print(my_tuple[0])

# print(dir(my_tuple))

# print(my_tuple[1:3])

# print(my_tuple.index("orange"))
# print(my_tuple.count("apple"))

# Set datatype

# myset = {1,2,3,4,5,6,7,56,4,3,5,6,7,3,"santhosh","vinesh","santhosh"}

# newset = {1,2,5,777}

# print(myset)

# myset.add(555)

# myset.update(newset)
# print(myset)

# # print(myset.union(newset))

# # print(myset)
# print(dir(myset))


# List , set and tuple
# List = mutable - change the value during runtime - add, update, delete, reverse, sorted
# Tuple = immutable - identify the count, index of a value but cannot add remove - cannot be modified
# Set = unique list of values - set related operations - union, intersection ....


# Dictionary

# country_state = {
#     "india": ["karnataka","kerala","tamilnadu"],
#     "us": ["california", "newyark"],
#     "germany": "berlin"
# }

# state_capital = {
#     "tamilnadu": "chennai",
#     "kerala": "thiruvananthapuram",
#     "karnataka": "bangalore"
# }

# # country_state.update(state_capital)

# print(type(country_state))

# print(country_state["us"])

# country_state["england"] = ["London","wales","scotland"]

# print(country_state)

# del country_state["germany"]

# print(dir(country_state))

# print(country_state.get("Australia"))

# print(country_state.values())

# print(country_state.pop("us"))

# print(country_state)

# print(country_state.setdefault("Australia","Canberra"))

# # print(country_state.fromkeys("santhosh",["texas","melbourne"]))

# # print(country_state)

# print(country_state)


# a = [
#     212,
#     213,
#     123,
#     213,
#     4,
#     10,
#     32,
#     35,
#     80,
#     70,
#     60,
#     95,
#     435,
#     324,
#     342,
#     2343,
#     23,
#     423,
#     423,
#     423,
#     42,
#     34,
#     234,
#     234,
#     23,
#     423,
#     42,
#     34,
#     234,
#     23,
#     423,
#     4,
#     234235,
#     345,
#     657,
# ]
# b = ["santhosh", "vinesh", "nanda", "ashif"]
# c = [10, 213, 34, "santhosh", "vinesh"]

# # Flow control - for, while - statements (break, pass, continue)
# lists, string , dictionary, tuple
# for loop

# ispresent = 10 in a
# print(ispresent)


# print(range(10,20))
# for index in range(10,20):
#     print(index)

# retriving by value
# sum = 0
# for item in a:
#     if item %2 == 0:
#         print(item)


# print("The sum of array a is ",sum)

# retriving by index
# sum = 0
# length = len(a)
# for index in range(length):
#     if a[index] % 2 == 0:
#         if a[index] %10 ==0:
#             continue
#             # break 
#         print(a[index])
#         print("Printing even numbers")

# a = [12, 23, 43, 54, 65, 54, 33, 22, 44, 55]
# index = 0
# while index < len(a):

#     print(a[index])

#     index = index + 1

# print("done")


# name = "santhosh"

# # for letter in name:
# #     print(letter)

# # vowels = ['a','e','i','o','u']
# for letter in name:
#     if letter in ['a','e','i','o','u']:
#         print(letter)


