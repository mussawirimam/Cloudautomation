# user defined modules
# built-in modules # math, os, random
# external modules - numpy, pandas, request, boto3

# built-in modules
# import math as m

# print(dir(m))

# print(m.sqrt(25))


from math import *
import os


print(sqrt(25))
print(pi)

print(dir(os))

# os.mkdir("newdirectory")

# n = 10
# div = 0
# print(n/div)

# #another operation
# os.mkdir("newdirectory")


try:
    #some operations 
    n = 10
    div = 2
    print(n/div)
    
    #another operation
    os.mkdir("newdirectory")
# except ZeroDivisionError:
#     print("The arithmetic operation has issue with Zero Division erro")
# except FileExistsError:
#     print("The file/folder that you try to create is already present")
    
except Exception as e:
    print(e)

print("Hello")

print(os.getcwd())

import datetime

print(dir(datetime))

print(datetime.datetime.now())

import sys

print(dir(sys))

print(sys.path)
print(sys.version)

#======================================================

import python.newdirectory.myownmodule as myownmodule

print(dir(myownmodule))

print(myownmodule.add(5,6))

print(myownmodule.greetings("Santhosh"))