import boto3
# from rich import print
from rich import print
# print(dir(rich))


# ec2 = boto3.client("ec2")

# print(dir(ec2))

session = boto3.Session(region_name="us-east-1")

# # print(dir(session))

print("Supported resources",session.get_available_resources()) # display the services supported by resources
print("supported client services",session.get_available_services()) # display the services supported by client


# # my_s3 = session.client("s3")

my_ec2 = session.resource("ec2")

# # print(dir(my_s3))

# # list_of_new_bucket = ["vinesh-s3-boto3-class","vinesh-s3-boto3-class-1","vinesh-s3-boto3-class-2","vinesh-s3-boto3-class-3"]

# # # for i in list_of_new_bucket:
# # #     response = my_s3.create_bucket(Bucket=i)

# # #     print(response)

# # print("===========================before deletion===========================")
# # response = my_s3.list_buckets()
# # print(response)
# # print("=====================================================================")
# # for i in list_of_new_bucket:
# #     print("Deleting the bucket ->",i)
# #     response = my_s3.delete_bucket(Bucket=i)
# #     print(response)
    
# # print("===========================after deletion============================")
# # response = my_s3.list_buckets()
# # print(response)
# # print("=====================================================================") 

iam_resource = session.resource("iam")

iam_client = session.client("iam")

# # print(dir(iam_resource))

all_users = iam_resource.users.all()

for i in all_users:
    print(i.name)

# print("=====================================================================") 

# print(dir(iam_client))

users_data = iam_client.get_user()

print(users_data)