# Class - its a blueprint of an object
# Object - has its own attributes and behaviours(method)
# 

# Bird - class
# eagle = wings, eyes, voice
# eagle - fly, eat

# class BankAccounts:
#     # attribute
    
#     # constructor
#     def __init__(self, act_num, act_name, bal=0):
#         self.account_name = act_name
#         self.balance = bal
#         self.account_num = act_num
      
#     # functionalies / method  
#     def check_balance(self):
#         print("The bank balance:",self.balance)
#         print("The account nubmer is",self.account_num)
#         print("The account belongs to",self.account_name)

# act1 = BankAccounts(123,"santhosh",23489897389274)

# act2 = BankAccounts(345,"Aasif",87098093809283)

# act1.check_balance()
# act2.check_balance()

# print(act1.balance)

# print(dir(act1))


# Inheritance

class Birds:
    
    def __init__(self, name):
        self.name = name
    
    def fly(self):
        print("My name is ",self.name, "I can fly")
        
class Dove(Birds):
        
    def display(self):
        print("I'm dove bird and my name is",self.name)
        
       
class Parrot(Birds):
    def __init__(self,name):
        self.name = name 
    
    def display(self):
        print("I'm a parrot and my name is ",self.name)

dove1 = Dove("april_dove")
dove1.fly()

parrot1 = Parrot("red_parrot")
parrot1.display()
parrot1.fly()