

# a = 15

# if a %2 == 0:
#     print("the number given is even")
# else: 
#     print("the number given is odd number")
    
# b = 25

# if b %2 == 0:
#     print("the number given is even")
# else: 
#     print("the number given is odd number")
    
# c= 42

# if c %2 == 0:
#     print("the number given is even")
# else: 
#     print("the number given is odd number")
    
# print("hello")

# # a ="10.5"
# # calculate()
# ######################################################
# def vinesh_calculator(yournumber):
#     if yournumber%2 == 0:
#         print("the number",yournumber, "is even")
#     else:
#         print("The number",yournumber, "is odd ")
# ######################################################
# def asif_calculator(firstnumber, secondnumber):
#     print(firstnumber)
#     print(secondnumber)
#     sum = firstnumber + secondnumber
#     if sum % 2 == 0:
#         print("even")
#     else:
#         print("odd")


# print("after function definition")

# ######################################################
# mylist = (2,3,45,6,76,7,6,453,5,4365,456,547,65,754,643,5,345,3)

# for mynums in mylist:
#     vinesh_calculator(mynums)
    
# newlist = [(1,3),(54,23),(34,45),(43,34)]

# for mytuples in newlist:
#     asif_calculator(mytuples[1],mytuples[0])
    
# print("after function call")

# # print(dir())

# def addition (a,b):
#     sum = a+b
#     return sum

# a = 15
# b= 25

# c = addition(a,b)




# find second largest number


# mylist = [234,234,345435,654,6,45,34,23,42,35,436,54,645,4534,34,23,42,342342343]

# firstlarge = 0
# secondlarge = 0

# for num in mylist:
#     print("the first large is ",firstlarge)
#     print("the second large is ", secondlarge)

#     if num > firstlarge:
#         secondlarge = firstlarge
#         firstlarge = num
#     elif num > secondlarge:
#         secondlarge = num

# print("the first large is ",firstlarge)
# print("the second large is ", secondlarge)
# 6 - fl=0, sl =0
# 6 > 0 => true , sl = 0, fl = 6

# 4 - fl = 6, sl= 0
# 6> 4 => false 4>0=>true, sl = 4

# 7 , fl =6, sl = 4
# 7>6 => true, sl = 6, fl = 7

# 9 ,  sl = 6, fl = 7
# 9 >7 => sl = 7, fl=9

#3, sl = 7, fl=9
# 3>9 => false. 3>7 => false 

#0 , sl = 7, fl=9
# 0>9 -> false, 0>7 -> false

# 1, sl = 7, fl=9
# 1>9 -> false, 1>7-> false

#sl = 7, fl=9



# # count the repeated numbers:

# a = [1,2,3,4,5,6,7,8,76,5,4,4,3,2,2,1]

# unique_a = set(a) #[1,2,3,4,5,6,7,8,76]

# repeated_num = []

# for i in unique_a:
#     if a.count(i) > 1:
#         repeated_num.append((i,a.count(i)))
# print(repeated_num)

file1=open("newtext.txt","a+")
file2=open("mytext.txt")

print(file1.tell())

print(file1.seek(0))
# print(dir(file1))

# content = file1.read()

# print(content)

# line1 = file1.readline()
# print(line1)

# print(file1.tell())

# line2 = file1.readline()
# print(line2)

all_lines = file1.readlines()

print(all_lines)

for i in all_lines:
    print(i)

# file1.close()

# value = "santhosh, vinesh, aasif, nanda"
# file1.write(value)

# print(file1.tell())
# with open("newtext.txt") as file1:
#     content = file1.read()
#     print(content)

print("File is closed")
print(dir(file1))