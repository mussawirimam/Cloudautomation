print("hello! welcome to python!")

# name = "Santhosh"

# phone = 9000000

# salary = 324234298.324987

name, phone, salary = "Santhosh", 98903289408, 43324234.234234

mycomplextnum = 4+3j

# print(type(name))

# print(type(phone))

# print(type(salary))

# print(type(mycomplextnum))

# print(name)

# # implicit type conversion
# a =10
# b = 15.5
# c = a+b
# print(type(a))
# print(type(b))
# print(type(c))

# c = str(c)
# print(c)
# print(type(c))

# explicit type conversion
# c = int(a+b)
# print(c)
# print(type(c))

# name = "santhosh"

# int_name = int(name)
# print(int_name)


# Operators:
# Arithmetic operator

########### + - * / % // **

a = 10
b = 3

# print(a+b)
# print(a-b)
# print(a*b)
# print(a/b)
# print(a%b) #modulo
# print(a//b) # floor
# print(a**b)

# Logical operator

# a = True
# b= False

# print(a and b) # false
# print(a or b) # true
# print(not a) # false


# Bitwise operator

# a = 8 # 00001000 00000010

# b = 7 # 00011110 00011110

# print(a|b)
# print(~a)
# print(a^b)
# print(a>>2)
# print(a<<2)

# Relational operator > < >= <= == !=

a = 10
b = 5

# print(a!=b)

# Assignment operator

a = 10
b = 5
c = 10

# a = a + 15
# a += 15
# a -= 4 # a = a - 4
# a *= 2 # a = a *2
# a /= 4 # a = a /4

# a //=2 # a = a // 2


# special operator "is"
# print(a is c)

# print(a is not b)

# # membership operator "in"

# a = [[10,231],342,34,43]
# b = [10,231]

# print( b in a )

# name = "santhosh"

# subname= "san"

# print(subname in name)
