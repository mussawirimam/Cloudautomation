

def add(a,b):
    return a+b

def greetings(name):
    
    greets = f"Hey {name}! Welcome to python modules!"
    return greets

def multiply(a,b):
    return a*b